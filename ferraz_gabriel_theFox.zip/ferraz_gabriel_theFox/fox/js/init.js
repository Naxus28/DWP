console.log('working');

$('img').hide();